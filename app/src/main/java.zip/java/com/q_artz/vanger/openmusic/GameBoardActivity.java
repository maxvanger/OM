package com.q_artz.vanger.openmusic;

import android.animation.ValueAnimator;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayout;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;


import com.q_artz.vanger.openmusic.MVP.GameBoardView;
import com.q_artz.vanger.openmusic.MVP.PuzzlePresenter;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import static android.content.DialogInterface.BUTTON_NEUTRAL;
import static android.content.DialogInterface.BUTTON_POSITIVE;

public class GameBoardActivity extends AppCompatActivity implements GameBoardView, DialogScore.DialogScoreAction {

    private GridLayout grid;

    private PuzzlePresenter mPresenter;
    private Bitmap puzzleImage;
    private ListView listGuessed;
    private ArrayAdapter<String> adapterGuessed;
    private List<String> guessedPuzzles;
    private int countPuzzles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_board_layout);

        mPresenter = PuzzlePresenter.getInstance(this);
        countPuzzles = mPresenter.getX()*mPresenter.getY()/2;
        mPresenter.loadGame();

        grid = (GridLayout) findViewById(R.id.grid_space);
        grid.setColumnCount(mPresenter.getX());

        listGuessed = (ListView)findViewById(R.id.titles_list);
        guessedPuzzles = new ArrayList<>(countPuzzles);
        adapterGuessed = new ArrayAdapter<>(this,R.layout.guessed_item,guessedPuzzles);
        listGuessed.setAdapter(adapterGuessed);
    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onStop() {
        super.onStop();
        mPresenter.onStop();
    }

    @Override
    public void onReadyToPlay() {
        //get Bitmap for puzzle image - from Presenter
        puzzleImage = BitmapFactory.decodeResource(getResources(),R.drawable.kartinka);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) grid.getLayoutParams();
        float ratio = (float)puzzleImage.getWidth()/puzzleImage.getHeight();
        if ((dm.heightPixels-72) * ratio > dm.widthPixels) {
            lp.width = Math.round(dm.widthPixels * 0.9f);
            lp.height = Math.round(lp.width / ratio);
        } else {
            lp.height = Math.round((dm.heightPixels-76) * 0.85f);
            lp.width = Math.round(lp.height * ratio);
        }
        grid.setLayoutParams(lp);
        grid.requestLayout();

        fillGrid(mPresenter.getX()*mPresenter.getY());
    }

    private void fillGrid(int count) {
        ViewGroup viewGroup;
        View frontView;
        ImageView backView;

        int dX = puzzleImage.getWidth() / mPresenter.getX();
        int dY = puzzleImage.getHeight() / mPresenter.getY();

        for (int i = 0; i < count; i++) {
            viewGroup = (ViewGroup) getLayoutInflater().inflate(R.layout.item_lock_view, grid, false);
            frontView = viewGroup.getChildAt(0);
            frontView.setId(i);
            frontView.setOnTouchListener(new PuzzleOnTouchListener());
            setBackground(frontView,getResources().getDrawable(R.drawable.q_empty1));

            backView = (ImageView) viewGroup.getChildAt(1);
            backView.setImageBitmap(getPuzzleImage(puzzleImage, i, dX, dY));
//            backView.setDrawingCacheEnabled(true);
//            backView.buildDrawingCache();

            grid.addView(viewGroup);
        }
    }

    public void replayGame(){
        ViewGroup viewGroup;
        View frontView;
        ImageView backView;

        //get new PuzzleImage
        guessedPuzzles.clear();
        adapterGuessed.notifyDataSetChanged();

        for(int i=0;i<grid.getChildCount();i++){
            viewGroup = (ViewGroup) grid.getChildAt(i);
            frontView = viewGroup.getChildAt(0);
            backView = (ImageView) viewGroup.getChildAt(1);
            flipViews(backView,frontView);
            //backView.setImageBitmap(getPuzzleImage(puzzleImage, i, dX, dY));
        }
    }

    private class PuzzleOnTouchListener implements View.OnTouchListener {
        @Override
        public boolean onTouch(View view, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    mPresenter.touch(view.getId());
                    return true;
                case MotionEvent.ACTION_CANCEL:
                case MotionEvent.ACTION_UP:
                    mPresenter.untouch(view.getId());
                    return true;
            }
            return true;
        }
    }

    @Override
    public void touchPuzzleAnim(int index) {
        grid.getChildAt(index)
                .animate().scaleX(1.12f).scaleY(1.12f).setDuration(100).start();
    }

    @Override
    public void untouchPuzzleAnim(int index) {
        grid.getChildAt(index)
                .animate().scaleX(1f).scaleY(1f).setDuration(100).start();
    }

    @Override
    public void bingo(int attemptsCount) {
        FragmentManager fm = getSupportFragmentManager();
        DialogScore dialogScore = DialogScore.newInstace(attemptsCount+countPuzzles,countPuzzles);
        dialogScore.show(fm,"DIALOG SCORE");
    }


    @Override
    public void setAlbumTitle(String title) {

    }

    @Override
    public void setCoupleTitle(String title) {

    }

    @Override
    public void showHintView(String text) {

    }

    @Override
    public void guessedRight(String title) {
        guessedPuzzles.add(title);
        adapterGuessed.notifyDataSetChanged();
        listGuessed.smoothScrollToPosition(guessedPuzzles.size());
    }

    @Override
    public void flipPuzzle(int index) {
        ViewGroup vg = (ViewGroup) grid.getChildAt(index);
        flipViews(vg.getChildAt(0),vg.getChildAt(1));
    }

    private ValueAnimator flipViews(View front, View back) {
        ValueAnimator flipAnimator = ValueAnimator.ofFloat(0f, 1f);
//            int direction = (int) (Math.random() * 100) % 4;
        flipAnimator.addUpdateListener(new FlipListener(front, back, 1));
        flipAnimator.setDuration(800);
        flipAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        //flipAnimator.setEvaluator(new FloatEvaluator());
        flipAnimator.start();
        return flipAnimator;
    }

    private void setBackground(View view, Drawable cardFrontDrawable) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            view.setBackground(cardFrontDrawable);
        } else
            view.setBackgroundDrawable(cardFrontDrawable);
    }

    private Bitmap getPuzzleImage(Bitmap source, int count, int sizeX, int sizeY) {
        int x = count % mPresenter.getX();
        int y = count / mPresenter.getX();
        Bitmap result = Bitmap.createBitmap(source, x * sizeX, y * sizeY, sizeX, sizeY);
        return result;
    }

    @Override
    public void dialogAction(int action) {
        switch (action) {
            case BUTTON_POSITIVE:
                mPresenter.nextGame();
                break;
            case BUTTON_NEUTRAL:
                mPresenter.replayGame();
        }
    }
}
