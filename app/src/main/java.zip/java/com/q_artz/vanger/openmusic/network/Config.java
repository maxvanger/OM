package com.q_artz.vanger.openmusic.network;

/**
 * Created by Vanger on 18.01.2017.
 */

public class Config {
    public static final String CLIENT_ID="cUa40O3Jg3Emvp6Tv4U6ymYYO50NUGpJ";
    public static final String API_URL="https://api.soundcloud.com";
}
